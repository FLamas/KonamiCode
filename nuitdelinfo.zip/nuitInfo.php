<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
        //nom d'utilisateur
        $userName = trim($_POST['userName']);
        //Le code sous format  fichier
        $fileCodeName = $_FILES['fileCode']['name'];
        //source of fileCode sended
        $srcFileCode= $_FILES['fileCode']['tmp_name'];
        //extension of file code sended
        $extension = substr(strrchr($_FILES['fileCode']['name'],'.'),1);

        $pureFileName = substr($fileCodeName, 0, (strlen($fileCodeName) - strlen($extension) -1) );     
        //specification
        $specification = htmlspecialchars(trim($_POST['specification']));

        //if user has already a directory in server
        //$userFolders = scandir("Files/Human");

        
        $serverRootDirectory = "NuitInfoDirectory/"; // OKKO our server root dir
        $existe = "false";
        $dh  = opendir($serverRootDirectory);

        //process the whole root dir
		while (false !== ($dirName = readdir($dh))) {
			if($dirName == $userName ){
				//echo $dirName."<br/>";
				$existe = "true";
				//return "true";
			}
		}//end While	

		//user directory don't exist in server root directory
		if($existe == "false"){
			chdir($serverRootDirectory);
			//create user directory in server
			mkdir($userName);
			//access to the new created Directory
			chdir($userName);

			//+---------------------------------------------------+
				if( $specification != null && $fileCodeName != null){
				//echo "fileCode ---- specification";
				//copy a file for textCode
				$res=move_uploaded_file($srcFileCode,$fileCodeName);

				//create a file for Specification
				$fileOfSpecificationPasted = fopen($pureFileName."_Spec.txt","w");
			    fwrite($fileOfSpecificationPasted,$specification);
				fclose($fileOfSpecificationPasted);
			}
			//+---------------------------------------------------+

		}//end else doesn't exist

		//user directory exist so we copy and paste files into it
		else{
			//transit to user Directory
			chdir($serverRootDirectory);
			chdir($userName);
			//+---------------------------------------------------+
            if( $specification != null && $fileCodeName != null){
				//copy a file for textCode
				$res=move_uploaded_file($srcFileCode,$fileCodeName);

				//create a file for Specification
				$fileOfSpecificationPasted = fopen($pureFileName."_Spec.txt","w");
				fwrite($fileOfSpecificationPasted,$specification);
				fclose($fileOfSpecificationPasted);
			}
			//+---------------------------------------------------+

		}//end else exist

	echo '<div style="align:center; color:green;font-size:14pt;" >File Uploaded Successfully</div>';
	echo '<div style="align:center; color:green;font-size:14pt;" >View XML File at 
	<a href="http://okkowenoteamleader.000webhostapp.com/users.xml" >Link</a>
	</div>';
//+-------------------------------------------------------------------------------+
// generate XML file from the Hierarchy of user Folders, Codes, and Specifications
//+-------------------------------------------------------------------------------+
function generateXMLFile($parentDir)
		{
$dir = scandir($parentDir);
$result = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<users>";
for ($i=0; $i < count($dir); $i++) { 
	if($dir[$i] == "." || $dir[$i] == ".." ){}
		else
		{
			//echo "=== ".$dir[$i]." ===<br/>";
			if ( $handle = opendir($parentDir."".$dir[$i]) ) {
			$result .= "<user name=\"{$dir[$i]}\">";
			while (false !== ($file = readdir($handle)))
        	{
            if(in_array($file, array('.', '..'))) continue;

	            if( !is_dir($parentDir ."/".$file) ){
	            	//recupérer l'extension pour la mettre comme attribut type du code
	            	$typeFile = substr(strrchr($file,'.'),1);

	            	$pureFileName = substr($file, 0, (strlen($file) - strlen($typeFile) -1) );
	                $result.= "<code type=\"{$typeFile}\">{$pureFileName}</code>" ;
	            }    
        	}
        		$result .= "</user>";
		}//end if

		}//end else
	}//end for
	$result .= "</users>";

			$xmlOutput = fopen("../../usersOutput.xml","w");
			fwrite($xmlOutput,$result);
			fclose($xmlOutput);

//echo $result;
}


//generateXMLFile("https://files.000webhost.com/NuitInfoDirectory/");

echo '<center><h1>WE ARE NO TEAM LEADER</h1></center>';
    echo 'redirecting to home in 10 sec';
   echo '<meta http-equiv="Refresh" content="10;URL=/">';
}//end POST

?>