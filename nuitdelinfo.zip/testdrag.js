let isSwapingBackground = false;
let isDraggable = false;

var Press = false;
var Konami = false;
var combo = 0;

			
document.addEventListener('keydown',keyD_Activer);
document.addEventListener('keyup',keyU_Activer);			




function keyD_Activer(e)
{
	// ù pour reset
	if(e.keyCode == '165')
	{
		document.getElementById("K").style.visibility  ='hidden';
		combo=0;
	}	
	// haut
	if((e.keyCode == '38') && (!Press) && ((combo == 0) || (combo == 1)))
	{				
		Press=true;
					
	}
	else if ((e.keyCode == '38') && !Press && (combo == 2))
		{
			combo=1;
			Press=true;
		}
		else if ((combo == 0) || (combo == 1)  && !Press)
			{
				combo=0;
			}
	
	// bas
	if((e.keyCode == '40') && (!Press) && ((combo == 2) || (combo == 3)))
	{				
		Press=true;			
	}
	else if((combo == 2) || (combo == 3)  && !Press)
	{
		combo = 0;
	}
	
	// droite
	if((e.keyCode == '39') && (!Press) && ((combo == 5) || (combo == 7)))
	{				
		Press=true;			
	}
	else if((combo == 5) || (combo == 7)  && !Press)
	{
		combo = 0;
	}
	
	//gauche
	if((e.keyCode == '37') && (!Press) && ((combo == 4) || (combo == 6)))
	{				
		Press=true;			
	}
	else if((combo == 4) || (combo == 6)  && !Press)
	{
		combo = 0;
	}
	
	//B
	if((e.keyCode == '66') && (!Press) && (combo == 8))
	{				
		Press=true;			
	}
	else if((combo == 8)   && !Press)
	{
		combo = 0;
	}
	
	//A
	if((e.keyCode == '65') && (!Press) && (combo == 9))
	{				
		Press=true;			
	}
	else if((combo == 9)   && !Press)
	{
		combo = 0;
	}	
}

function keyU_Activer(e)
{	
	
	// haut
	if((e.keyCode == '38') && (Press) )
	{				
		Press=false;
		combo+=1;			
	}
	else if (((combo == 0) || (combo == 1))  && Press)
	{
		combo=0;
	}
	// bas
	if((e.keyCode == '40') && (Press) )
	{						
		Press=false;
		combo+=1;			
	}
	else if (((combo == 2) || (combo == 3))  && Press)
	{
		combo=0;
	}
	// droite
	if((e.keyCode == '39') && (Press) )
	{						
		Press=false;
		combo+=1;			
	}
	else if (((combo == 5) || (combo == 7))  && Press)
	{		
		combo=0;
	}
	//gauche
	if((e.keyCode == '37') && (Press) )
	{								
		Press=false;
		combo+=1;			
	}
	else if (((combo == 4) || (combo == 6))  && Press)
	{
		combo=0;
	}
	//B
	if((e.keyCode == '66') && (Press) )
	{					
		Press=false;
		combo+=1;			
	}
	else if ((combo == 8)  && Press)
	{
		combo=0;
	}
	//A
	if((e.keyCode == '65') && Press)
	{	
	    console.log("hehexd")
		Press=false;
		combo+=1;
		Konami = true;
		document.getElementById("K").style.visibility  ='visible'; 
		hacking();
			
	}
	else if ((combo == 9)  && Press)
	{
		combo=0;
	}
	
}

function hacking()
{
if (Konami)
{
  cssModifications();

  document.getElementById("inviteCommande").style.visibility = "visible" ;
  console.log(Konami);

        if (typeof document.onselectstart!="undefined") {
          document.onselectstart=new Function ("return false");
        }
        else{
          document.onmousedown=new Function ("return false");
          document.onmouseup=new Function ("return true");
        }

      }
}

function saisieClavier(event)
{
    if(event.keyCode == 13){
        var texteSaisie = $('#monInput').val();
        if(texteSaisie === "/setSwapingBackground = true"){
          isSwapingBackground = true;
          swappingBackground();
        }
        if (texteSaisie === "/setSwapingBackground = false"){
          isSwapingBackground = false;
          swappingBackground();
          }
        if (texteSaisie === "/showHelp = true"){
          let texte= document.getElementById('cli2');
          texte.style.color="green";
          texte.innerHTML = "/setDraggable = bool"+" /setSwapingColor = bool" + " /setLangageChange = bool" + " /setTagVisible = bool";

        }
        if (texteSaisie === "/showHelp = false"){
          let texte= document.getElementById('cli2');
          texte.innerHTML = "";
        }
        if(texteSaisie === "/setDraggable = true"){
          isDraggable = true;
          setDraggable();
        }
        if (texteSaisie === "/setDraggable = false"){
          isDraggable = false;
          setDraggable();
          }

          document.getElementById("monInput").value = "";
      }


    }

function color(){
      var n1 = Math.floor(Math.random()*255);
      var n2 = Math.floor(Math.random()*255);
      var n3 = Math.floor(Math.random()*255);
      document.body.style.backgroundColor = "rgb(" +n1+ "," +n2+ "," +n3+ ")";
}

function swappingBackground(){
  if (isSwapingBackground === true){
    let body = document.getElementsByTagName('body')[0];
    body.setAttribute("oncontextmenu","color();{return false}");
  }
  else{
    document.body.style.backgroundColor = "black";
    let body = document.getElementsByTagName('body')[0];
    body.setAttribute("oncontextmenu","{return true}");
  }
}

function setDraggable(){
  if (isDraggable ===true){
    var storage = {};


          function addEvent(element, event, func) {
              if (element.attachEvent) {
                  element.attachEvent('on' + event, func);
              } else {
                  element.addEventListener(event, func, true);
              }
          }


          function init() { // La fonction d'initialisation
              var elements = document.getElementsByTagName('h1'),
                  elementsLength = elements.length;

                    for (var i = 0 ; i < elementsLength ; i++) {
                        if (elements[i].className === 'draggableBox') {

                            addEvent(elements[i], 'mousedown', function(e) {
                                var s = storage;
                                s.target = e.target || event.srcElement;
                                s.offsetX = e.clientX - s.target.offsetLeft;
                                s.offsetY = e.clientY - s.target.offsetTop;
                            });

                            addEvent(elements[i], 'mouseup', function() {
                                storage = {};
                            });
                        }
                    }

                    addEvent(document, 'mousemove', function(e) {
                        var target = storage.target;

                        if (target) {
                            target.style.top = e.clientY - storage.offsetY + 'px';
                            target.style.left = e.clientX - storage.offsetX + 'px';
                        }
                    });
                      }
                init();




          function init2() { // La fonction d'initialisation
              var elements = document.getElementsByTagName('div'),
                  elementsLength = elements.length;
              for (var i = 0 ; i < elementsLength ; i++) {
                  if (elements[i].className === 'draggableBox') {

                      addEvent(elements[i], 'mousedown', function(e) {
                          var s = storage;
                          s.target = e.target || event.srcElement;
                          s.offsetX = e.clientX - s.target.offsetLeft;
                          s.offsetY = e.clientY - s.target.offsetTop;
                      });

                      addEvent(elements[i], 'mouseup', function() {
                          storage = {};
                      });
                  }
              }

              addEvent(document, 'mousemove', function(e) {
                  var target = storage.target;

                  if (target) {
                      target.style.top = e.clientY - storage.offsetY + 'px';
                      target.style.left = e.clientX - storage.offsetX + 'px';
                  }
              });

}
          init2();

          function init3() { // La fonction d'initialisation
              var elements = document.getElementsByTagName('label'),
                  elementsLength = elements.length;

              for (var i = 0 ; i < elementsLength ; i++) {
                  if (elements[i].className === 'draggableBox') {

                      addEvent(elements[i], 'mousedown', function(e) {
                          var s = storage;
                          s.target = e.target || event.srcElement;
                          s.offsetX = e.clientX - s.target.offsetLeft;
                          s.offsetY = e.clientY - s.target.offsetTop;
                      });

                      addEvent(elements[i], 'mouseup', function() {
                          storage = {};
                      });
                  }
              }

              addEvent(document, 'mousemove', function(e) {
                  var target = storage.target;

                  if (target) {
                      target.style.top = e.clientY - storage.offsetY + 'px';
                      target.style.left = e.clientX - storage.offsetX + 'px';
                  }
              });
          }

          init3();

          function init4() { // La fonction d'initialisation
                        var elements = document.getElementsByTagName('button'),
                            elementsLength = elements.length;

                        for (var i = 0 ; i < elementsLength ; i++) {
                            if (elements[i].className === 'draggableBox') {

                                addEvent(elements[i], 'mousedown', function(e) {
                                    var s = storage;
                                    s.target = e.target || event.srcElement;
                                    s.offsetX = e.clientX - s.target.offsetLeft;
                                    s.offsetY = e.clientY - s.target.offsetTop;
                                });

                                addEvent(elements[i], 'mouseup', function() {
                                    storage = {};
                                });
                            }
                        }

                        addEvent(document, 'mousemove', function(e) {
                            var target = storage.target;

                            if (target) {
                                target.style.top = e.clientY - storage.offsetY + 'px';
                                target.style.left = e.clientX - storage.offsetX + 'px';
                            }
                        });
                    }

          init4();

          function init5() { // La fonction d'initialisation
              var elements = document.getElementsByTagName('input'),
                  elementsLength = elements.length;

              for (var i = 0 ; i < elementsLength ; i++) {
                  if (elements[i].className === 'draggableBox') {

                      addEvent(elements[i], 'mousedown', function(e) {
                          var s = storage;
                          s.target = e.target || event.srcElement;
                          s.offsetX = e.clientX - s.target.offsetLeft;
                          s.offsetY = e.clientY - s.target.offsetTop;
                      });

                      addEvent(elements[i], 'mouseup', function() {
                          storage = {};
                      });
                  }
              }

              addEvent(document, 'mousemove', function(e) {
                  var target = storage.target;

                  if (target) {
                      target.style.top = e.clientY - storage.offsetY + 'px';
                      target.style.left = e.clientX - storage.offsetX + 'px';
                  }
              });
          }

          init5();

          function init6() { // La fonction d'initialisation
              var elements = document.getElementsByTagName('select'),
                  elementsLength = elements.length;

              for (var i = 0 ; i < elementsLength ; i++) {
                  if (elements[i].className === 'draggableBox') {

                      addEvent(elements[i], 'mousedown', function(e) {
                          var s = storage;
                          s.target = e.target || event.srcElement;
                          s.offsetX = e.clientX - s.target.offsetLeft;
                          s.offsetY = e.clientY - s.target.offsetTop;
                      });

                      addEvent(elements[i], 'mouseup', function() {
                          storage = {};
                      });
                  }
              }

              addEvent(document, 'mousemove', function(e) {
                  var target = storage.target;

                  if (target) {
                      target.style.top = e.clientY - storage.offsetY + 'px';
                      target.style.left = e.clientX - storage.offsetX + 'px';
                  }
              });
              console.log("a") ;

          }

          init6();
  }
  else {
    console.log("Drag désactivé");
  }
}


function cssModifications(){
  var elmt = document.getElementsByTagName('body')[0];
  elmt.style.textShadow = "2px 0px white";
  elmt.style.textShadow = "0 0 3px #00ff1e";
  elmt.style.color = "green";
  elmt.style.backgroundColor = "#000000";
  elmt.style.minHeight="100%";
  elmt.style.margin="0";
  elmt.style.padding="0";

  elmt = document.getElementsByTagName('html');


  elmt = document.getElementById('userName');
  elmt.style.backgroundColor= "#00ff1e";
  elmt.style.opacity = "0.8";

  elmt = document.getElementById('loggin');
  elmt.style.paddingLeft= "10%";

  elmt = document.getElementsByTagName('h1')[0];
 
  elmt.style.fontSize = "30px";
  elmt.style.fontStyle = "normal";
  elmt.style.fontVariant = "normal";
  elmt.style.fontWeight = "700";
  elmt.style.lineHeight ="33px";

  elmt = document.getElementsByTagName('label')[0];
  elmt.style.fontFamily = "Arial";
  elmt.style.fontSize = "30px";
  elmt.style.fontStyle = "normal";
  elmt.style.fontVariant = "normal";
  elmt.style.fontWeight = "700";
  elmt.style.lineHeight ="33px";

  elmt = document.getElementById('conteneur');
  elmt.style.display= "flex";
  elmt.style.alignContent = "center";
  elmt.style.textShadow = "0 0 3px #00ff1e";
  elmt.style.textShadow = "0 0 5px #00ff1e";
  elmt.style.paddinTop = "5%";
  elmt.style.color = "white";
  elmt.style.marginTop="3%";
  elmt.style.height= "80vh";
  elmt.style.width= "80%";
  elmt.style.marginLeft= "10%";
  elmt.style.backgroundImage="url('matrice.gif')";
  elmt.style.opacity= "0.7";

  elmt = document.getElementById('test');
  elmt.style.paddingTop= "1%";
  elmt.style.display= "flex";

  elmt = document.getElementById('fileUpload');
  elmt.style.flex="1";
    elmt.style.marginLeft= "12.5%";
    elmt.style.paddingTop="11vh";

    elmt = document.getElementById('specification');
    elmt.style.flex="1";

 /* elmt = document.getElementsByTagName('input[type="submit"]')[0];
  elmt.style.width=" 10%";
    elmt.style.marginLeft=" 22%";
    elmt.style.textDecoration= "none";
    elmt.style.borderRadius= "26px";
    elmt.style.fontFamily= "Arial";
    elmt.style.color= "#1c061C";
    elmt.style.fontSize="24px";
    elmt.style.padding= "11px 24px 11px 24px";
    elmt.style.border= "solid  #00ff1e 3px";
    elmt.style.color="white";
    elmt.style.backgroundColor="transparent";*/

/*elmt = document.getElementsByTagName('input[type="text"]')[0];
elmt.style.height= "30px";
    elmt.style.borderRadius ="50px";*/

elmt = document.getElementsByTagName('textarea')[0];
elmt.style.width="90%";
  elmt.style.height=" 50vh";
  elmt.style.padding=" 25px 35px";
  elmt.style.boxSizing=" border-box";
  elmt.style.border= "2px solid #ccc";
  elmt.style.borderRadius= "50px";
  elmt.style.backgroundColor= "#f8f8f8";
    elmt.style.resize= "none";

elmt=document.getElementsByClassName('cli')[0];
  elmt.style.width= "866px";
  elmt.style.height= "70px";
  elmt.style.backgroundImage= "url(PBW.png)";
  elmt.style.border= "solid 2px";
  elmt.style.textShadow= "white 0px 0px 2px";
  elmt.style.fontSize= "16px";
  elmt.style.backgroundSize= "150px";

elmt=document.getElementsByClassName('input1')[0];
elmt.style.border= "none";
elmt.style.color="green";
elmt.style.backgroundColor= "black";

elmt=document.getElementById('cli2');
elmt.style.color = "green";
elmt.style.border ="none";
elmt.style.textShadow= "none";
}
