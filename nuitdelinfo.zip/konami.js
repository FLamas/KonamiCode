var Press = false;
var Konami = false;
var combo = 0;

			
document.addEventListener('keydown',keyD_Activer);
document.addEventListener('keyup',keyU_Activer);			




function keyD_Activer(e)
{
	// ù pour reset
	if(e.keyCode == '165')
	{
		document.getElementById("K").style.visibility  ='hidden';
		combo=0;
	}	
	// haut
	if((e.keyCode == '38') && (!Press) && ((combo == 0) || (combo == 1)))
	{				
		Press=true;
					
	}
	else if ((e.keyCode == '38') && !Press && (combo == 2))
		{
			combo=1;
			Press=true;
		}
		else if ((combo == 0) || (combo == 1)  && !Press)
			{
				combo=0;
			}
	
	// bas
	if((e.keyCode == '40') && (!Press) && ((combo == 2) || (combo == 3)))
	{				
		Press=true;			
	}
	else if((combo == 2) || (combo == 3)  && !Press)
	{
		combo = 0;
	}
	
	// droite
	if((e.keyCode == '39') && (!Press) && ((combo == 5) || (combo == 7)))
	{				
		Press=true;			
	}
	else if((combo == 5) || (combo == 7)  && !Press)
	{
		combo = 0;
	}
	
	//gauche
	if((e.keyCode == '37') && (!Press) && ((combo == 4) || (combo == 6)))
	{				
		Press=true;			
	}
	else if((combo == 4) || (combo == 6)  && !Press)
	{
		combo = 0;
	}
	
	//B
	if((e.keyCode == '66') && (!Press) && (combo == 8))
	{				
		Press=true;			
	}
	else if((combo == 8)   && !Press)
	{
		combo = 0;
	}
	
	//A
	if((e.keyCode == '65') && (!Press) && (combo == 9))
	{				
		Press=true;			
	}
	else if((combo == 9)   && !Press)
	{
		combo = 0;
	}	
}

function keyU_Activer(e)
{	
	
	// haut
	if((e.keyCode == '38') && (Press) )
	{				
		Press=false;
		combo+=1;			
	}
	else if (((combo == 0) || (combo == 1))  && Press)
	{
		combo=0;
	}
	// bas
	if((e.keyCode == '40') && (Press) )
	{						
		Press=false;
		combo+=1;			
	}
	else if (((combo == 2) || (combo == 3))  && Press)
	{
		combo=0;
	}
	// droite
	if((e.keyCode == '39') && (Press) )
	{						
		Press=false;
		combo+=1;			
	}
	else if (((combo == 5) || (combo == 7))  && Press)
	{		
		combo=0;
	}
	//gauche
	if((e.keyCode == '37') && (Press) )
	{								
		Press=false;
		combo+=1;			
	}
	else if (((combo == 4) || (combo == 6))  && Press)
	{
		combo=0;
	}
	//B
	if((e.keyCode == '66') && (Press) )
	{					
		Press=false;
		combo+=1;			
	}
	else if ((combo == 8)  && Press)
	{
		combo=0;
	}
	//A
	if((e.keyCode == '65') && Press)
	{	
	    console.log("hehexd")
		Press=false;
		combo+=1;
		Konami = true;
		document.getElementById("K").style.visibility  ='visible'; 
		hacking();
			
	}
	else if ((combo == 9)  && Press)
	{
		combo=0;
	}
	
}

